# KEC_IMG

This is purely an educational work,
It takes Images from an direct Kongu Engineering College Server,
So Improper Working is not an issue form this code !!!


Click Here !!!
https://ranjith-r-r.github.io/KEC_IMG/
